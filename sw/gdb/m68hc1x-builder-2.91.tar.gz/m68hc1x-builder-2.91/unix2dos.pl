#!/usr/bin/perl

while (<STDIN>) {
  chop;
  print "$_\r\n";
}
