#!/usr/bin/perl
#
# osx-install-m68hc1x-2.1.pl		Rob Barris, rbarris@mac.com  Nov 17, 2002
#
#   Nov 18, 2002: bug fix where we call bunzip2,
#   a mis-spelled Perl variable (- vs _).
#
# Installation script for the v2.1 release of the 68hc1x toolset at
#         http://stephane.carrez.free.fr/m68hc11_port.php
#         ( http://m68hc11.serveftp.org/gcc-m68hc1x-20040222.tar.gz )
#
# Some inspiration and terminology from original build-1.9d script by Mike Gruber
#         http://www.grubinski.com/grubinski/build.script.1.9d
#
# Instructions for use:
#
# 1. make a working directory and place this script file in it.
# 2. 'cd' to the working directory.
# 3. 'chmod +x osx-install-m68hc1x-2.1.pl'  to enable execute privilege on this script.
# 4. make sure the /usr/local dir exists on your system.  'sudo mkdir /usr/local' if not.
# 5. execute this script from the working dir: './osx-install-m68hc1x-2.1.pl'
#
# Files will be fetched, uncompressed and untarred from the following URL's:
#
# http://m68hc11.serveftp.org/gcc-m68hc1x-20040222.tar.gz
# http://ftp.gnu.org/pub/gnu/binutils/binutils-2.14.tar.bz2
# ftp://sources.redhat.com/pub/newlib/newlib-1.11.0.tar.gz
# http://ftp.gnu.org/pub/gnu/gdb/gdb-6.0.tar.gz
# http://ftp.gnu.org/pub/gnu/gcc/gcc-3.3.3/gcc-3.3.3.tar.gz
#
# Patches from inside gcc-m68hc1x-20040222.tar.gz will be applied to the other
# source trees before each piece is built.
#
# There is some logic to keep it from trying to download these files again
# and again if you successfully downloaded them once and ran the script twice.
#
# A shell script will be generated to apply the patches and run the make steps
# for each piece in order.
#
# Note the use of "sudo" to request admin privilege once each build has been done,
# to accomplish installation into /usr/local.
# This means the machine will stop to ask you for your admin password four times,
# once to install binutils, and again for GCC, GDB, and Newlib.
#
# I believe you can get around that by using 'sudo' to run the main script as a whole:
# 'sudo ./osx-install-m68hc1x-2.1.pl' but I have not tried this.
#
# This is only my third Perl program, so be nice!  It has only been tested on
# MacOS X 10.2 with the developer tools installed (required).
#
# Total make/install time on a 500MHz G4 runs around an hour depending on how much web
# surfing and CD ripping takes place during the builds.
#


$ok = 1;


print	"Checking for /usr/local...\n";
if (! -e "/usr/local/." )
{
	print	"Need to create /usr/local - enter admin password\n";
	if (system ("sudo mkdir /usr/local"))
	{
		print	"Could not create /usr/local.\n";
	}
	$ok = 0;
}


if ($ok)
{
	print	"Making sure we have all the pieces. \n";
	
		# get all the pieces.
	
	@urls = ();
	push @urls, "http://m68hc11.serveftp.org/gcc-m68hc1x-20040222.tar.gz";
	push @urls, "http://ftp.gnu.org/pub/gnu/binutils/binutils-2.14.tar.bz2";
	push @urls, "ftp://sources.redhat.com/pub/newlib/newlib-1.11.0.tar.gz";
	push @urls, "http://ftp.gnu.org/pub/gnu/gdb/gdb-6.0.tar.gz";
	push @urls, "http://ftp.gnu.org/pub/gnu/gcc/gcc-3.3.3/gcc-3.3.3.tar.gz";
	
	
	while( $ok && ($url = shift @urls) )
	{
		print " ### $url ### \n";
		
		# take apart the URL, figure out what the download name would be, what the tar name would be, what the dir name would be if unpacked.
		
		# find base name of URL
		@url_frags = split /\//, $url;
		
		$arc_name = pop @url_frags;	# everything after the final slash in the URL is the archive name
	
			# figure out .tar name after de-gzing or de-bz2ing
		$tar_name = $arc_name;
		$tar_name =~ s/.gz//g;
		$tar_name =~ s/.bz2//g;
			
			# figure out folder name after untar-ing
		$dir_name = $tar_name;
		$dir_name =~ s/.tar//g;
	
		if (! -e $dir_name )
		{
			# either we have it and it got renamed, or we do not have it at all.
			
			$renamed_dir_name = $dir_name . "-m68hc1x";
			
			if ( ! -e $renamed_dir_name )
			{
				# need the dir, need the tar for that
				if (! -e $tar_name )
				{
					# need the tar, we need the .gz or .bz2 for that
					if (!-e $arc_name)
					{
						print "Downloading $arc_name from $url...\n";
						
						my $dlresult = system("curl -O $url");
						if ($dlresult)
						{
							# something went wrong
							print " Could not download $url: status $dlresult\n";
							$ok = 0;
						}
						else
						{
							print " Downloaded $url OK.\n";
						}
					}
					
					if ($ok)
					{
						my $unzipresult = 0;
						
						if ($arc_name =~ /.gz/)
						{
							$unzipresult = system("gunzip $arc_name >& $dir_name.unzip.log");
						}
						elsif  ($arc_name =~ /.bz2/)
						{
							$unzipresult = system("bunzip2 $arc_name >& $dir_name.unzip.log");
						}
		
						if ($unzipresult)
						{
							# something went wrong
							print " Could not unpack $arc_name: status $unzipresult\n";
							$ok = 0;
						}
						else
						{
							print " Unpacked $arc_name OK.\n";
						}
					}
				}
				
				if ($ok)
				{
					print "Untarring $tar_name...\n";
					
					my $untarresult = system("tar -xvf $tar_name >& $dir_name.untar.log");
					
					if ($untarresult)
					{
						# something went wrong
						print " Could not untar $tar_name: status $untarresult\n";
						$ok = 0;
					}
					else
					{
						print " Untarred $tar_name OK.\n";
					}
				}
			}
			else
			{
				print "Already have $renamed_dir_name. Skipping download/untar...\n";
			}
	
			if ($ok)
			{
				if ( ! -e $renamed_dir_name )
				{
					# rename it (all but one)
					
					if (! ($dir_name =~ /gcc-m68hc1x-20040222/) )
					{
						print ("Renaming $dir_name to $renamed_dir_name\n" );
						
						if (system( "mv $dir_name $renamed_dir_name" ))
						{
							print " Problems renaming $dir_name ($url).\n";
							$ok = 0;
						}
					}
					else
					{
						print (" Not renaming $dir_name\n" );
					}
				}
			}
			else
			{
				print " Problems preparing $dir_name ($url).\n";
			}
		}
	}
}

if ($ok)
{
	print	"Locating and unpacking the hc1x diffs. \n";
	
	# all dirs downloaded and unpacked.
	
	# copy the .gz's from the snapshots folder
	@diffs = ();
	push @diffs, "m68hc1x-20040222/snapshots/binutils-2.14-m68hc1x-20040201.diffs.gz";
	push @diffs, "m68hc1x-20040222/snapshots/gdb-6.0-m68hc1x-20040222.diffs.gz";
	push @diffs, "m68hc1x-20040222/snapshots/gcc-3.3.3-m68hc1x-20040222.diffs.gz";
	push @diffs, "m68hc1x-20040222/snapshots/newlib-1.11.0-m68hc1x-20031001.diffs.gz";

	while($diff = shift @diffs)
	{	
		$cpresult = system( "cp $diff .");
		if (! $cpresult)
		{
			# unpack it
			@diff_frags = split /\//,$diff;
			$base_diff_name = pop @diff_frags;
			
			$unzipresult = system( "gunzip $base_diff_name");
			if (! $unzipresult)
			{
				# ready to patch.
			}
			else
			{
				print " Could not unpack $diff : status $unzipresult \n";
				$ok = 0;
			}
		}
		else
		{
			print " Could not find or copy $diff : status $cpresult \n";
			$ok = 0;
		}
	}	
}

if ($ok)
{
	# generate a shell script and run it
	
	# technique is to assign the following (very long) string constants into $script
	# and then do some search-and-replace on the ALL-CAPS values.
	
$script = <<'END'
# Build binutils

	echo
	echo
	echo "######################## Starting to build binutils ########################"
	echo
	echo

	cd BINUTILS-m68hc1x
	patch -p1 < ../BINUTILS-m68hc1x-20040201.diffs
	sh ./configure --target=TARGET --prefix=INSTALLDIR --program-prefix=PROGRAM_PREFIX
	make
	
		# this will prompt for a password
	sudo make install
	
	cd ROOTDIR
	rm -rf BINUTILS-m68hc1x
	
	# Further steps require the binutils we just built
	export PATH=INSTALLDIR/bin:$PATH


# Build gcc

	echo
	echo
	echo "######################## Starting to build gcc ########################"
	echo
	echo

	cd GCC-m68hc1x
	patch -p1 < ../GCC-m68hc1x-20040222.diffs
	sh ./configure --target=TARGET --prefix=INSTALLDIR --program-prefix=PROGRAM_PREFIX --enable-languages=c
	make
	
	sudo make install
	cd ROOTDIR
	rm -rf GCC-m68hc1x

# Build gdb

	echo
	echo
	echo "######################## Starting to build gdb ########################"
	echo
	echo

	cd GDB-m68hc1x
	patch -p1 < ../GDB-m68hc1x-20040222.diffs
	sh ./configure --target=TARGET --prefix=INSTALLDIR --program-prefix=PROGRAM_PREFIX
	make
	
	sudo make install
	cd ROOTDIR
	rm -rf GDB-m68hc1x


# Build newlib

	echo
	echo
	echo "######################## Starting to build newlib ########################"
	echo
	echo

	cd NEWLIB-m68hc1x
	patch -p1 < ../NEWLIB-m68hc1x-20031001.diffs
	cd ..
	mkdir build-newlib
	cd build-newlib
	sh ../NEWLIB-m68hc1x/configure --target=TARGET --prefix=INSTALLDIR --program-prefix=PROGRAM_PREFIX
	make CFLAGS="-g -Os -Wall -mrelax"
	
	sudo make install
	cd ROOTDIR
	rm -rf NEWLIB-m68hc1x
	rm -rf build-newlib
END
;


	$ROOTDIR		=	`pwd`;
	$BINUTILS		=	"binutils-2.14";
	$GCC			=	"gcc-3.3.3";
	$GDB			=	"gdb-6.0";
	$NEWLIB			=	"newlib-1.11.0";
	$TARGET			=	"m6812-elf";
	$PROGRAM_PREFIX	=	"m6812-elf-";
	$INSTALLDIR		=	"/usr/local";

		# substitute strings in the template above.
		
	$script =~ s/BINUTILS/$BINUTILS/g;
	$script =~ s/GCC/$GCC/g;
	$script =~ s/GDB/$GDB/g;
	$script =~ s/NEWLIB/$NEWLIB/g;
	$script =~ s/TARGET/$TARGET/g;
	$script =~ s/PROGRAM_PREFIX/$PROGRAM_PREFIX/g;
	$script =~ s/INSTALLDIR/$INSTALLDIR/g;
	$script =~ s/ROOTDIR/$ROOTDIR/g;

		# print a copy of the final script on the console.
	print "Make and Install Script as follows: \n\n$script \n\n";
	
		# execute the script. Comment out this line with '#' if you would like to see the generated script
		# (you can run the main script more than once in the same work dir without having to start over).
		
	$builderr = system("$script\n");
	
	print "\n\nFinal status = $builderr \n\n";
}
