#!/bin/sh
DIR=/usr/src/RPM/RPMS/i586

if ! test -f filelist.pl; then
    echo "filelist.pl must be created from filelist.perl" 1>&2
    exit 2
fi

ORIG=`pwd`
BINUTILS=binutils-68hc1x-win32-2.14-2.91.i586.rpm
GDB=gdb-68hc1x-win32-6.0-2.91.i586.rpm
GCC=gcc-68hc1x-win32-3.3.3-2.91.i586.rpm
NEWLIB=newlib-68hc1x-win32-1.11.0-2.91.i586.rpm

ZIPFILE=$ORIG/gnu-hc1x-2.91.zip

mkdir /tmp/tmp.$$
cd /tmp/tmp.$$
rpm2cpio $DIR/$BINUTILS | (cpio --no-absolute-filenames --make-directories \
			        -m --extract)

rpm2cpio $DIR/$GDB | (cpio --no-absolute-filenames --make-directories \
			        -m --extract)

rpm2cpio $DIR/$GCC | (cpio --no-absolute-filenames --make-directories \
			        -m --extract)

rpm2cpio $DIR/$NEWLIB | (cpio --no-absolute-filenames --make-directories \
			        -m --extract)
# Make sure we have write permission to add/remove directories
find /tmp/tmp.$$ -type d -print | xargs chmod u+w

cp $ORIG/winstall.exe /tmp/tmp.$$/usr/bin/winstall.exe &&

mv usr m6811
cd m6811 &&
(perl $ORIG/filelist.pl > $ORIG/gnu-hc1x-2.91.iss) &&
cd .. &&
zip -r $ZIPFILE m6811
cd /tmp
rm -rf tmp.$$


