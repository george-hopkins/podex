#!/usr/bin/perl
#
# Copyright (C) 1999, 2000, 2001, 2002, 2004 Stephane Carrez
#
# This file is part of SCT
#
# SCT is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# SCT is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
#
# ######################################################################
sub help { select(STDERR); print <<EOF;

fileList

Usage:	fileList-tree [-v] [-help] [-x pattern] src-dir new-dir

Creates the Inno Setup file for 68HC11 tool chain

-v		Verbose mode
-help		Help message
-x pattern	Exclude files/directories matching the pattern

EOF

    exit(0);
}


sub message {
    local($msg) = @_;

    if ($verbose) {
	print STDOUT "$Indent$msg";
    }
}

$errors_count = 0;
sub error {
    local($msg) = @_;

    print STDERR "$msg\n";
    $errors_count++;
}

$SEP="/";
$|=1;

#
# Role :	Returns the base name of a file
#
# Usage:	&Basename (<path>)
#
sub Basename {
    local ($dir) = @_;
    local ($pos);

    $pos = rindex ($dir, $SEP);
    if ($pos >= 0) {
	$pos = $pos + 1;
	$dir = substr ($dir, $pos);
    }

    return $dir;
}

#
# Role :	Returns the directory name of a file
#
# Usage:	&Dirname (<path>)
#
sub Dirname {
    local ($dir) = @_;
    local ($pos);

    $pos = rindex ($dir, $SEP);
    if ($pos >= 0) {
	$dir = substr ($dir, 0, $pos);
    } else {
	$dir = ".";
    }
    return $dir;
}

#
# Role :	Recursively creates a directory
#
# Usage :	&Mkdir (<path>)
#
sub Mkdir {
    local ($dir) = @_;
    local ($pdir);

    #print STDOUT "Creating $dir\n";

    if (! -d $dir) {
	$pdir = &Dirname ($dir);
	return 1 if (&Mkdir ($pdir) != 0);
	if (! -d $dir) {
	    return 1 if (! mkdir ($dir, 0755));
	}
    }
    
    return 0;
}

sub ReadDirectory {
    local($dirname) = @_;
    local(@names);
    local($file, $ok);

    $curDirPath=$dirname;
    @dirFiles = ();
    if (! opendir(DIR, $dirname)) {
	return @dirFiles;
    }

    #
    # Get directory entries in the table.
    #
    @names = readdir(DIR);
    closedir(DIR);

    #
    # Build in array `files' the list of names we are really interested in
    # (hacked from mksnap).
    #
    for (@names) {
	# Ignore . and .. entries, files beginning with `.'
	# and editor saved files (beginning by  `#', `%' or
	# ending with  `~')
	# Also ignore SCCS , files
	#
	next if (/^[.#%]/ || /~$/);

		    # Ignore , files (SCCS renamed files)
	next if (/^,/);

	$file=$_;
	$ok=1;
	for (@exclude) {
	   if ($file =~ $_) {
	      $ok=0;
	      last;
	   }
	}
	if ($ok == 1) {
	    push(@dirFiles, $file);
	}
    }

    return @dirFiles;
}


sub walk_tree {
    local($path) = @_;
    local(@names);
    local($name);
    local($old_slink_dir);

    &message("\033[KWalk $path\n");
    @names = &ReadDirectory("$src_dir$path");
    for (@names) {
       $name = "$path/$_";
       if (-d "$src_dir$name") {
	  push(@allDirs, "$src_dir$name");
	  $old_slink_dir = $slink_dir;
	  if (!($slink_dir =~ /^\//)) {
	      $slink_dir = "../$slink_dir";
	  }
	  &walk_tree($name);
	  $slink_dir = $old_slink_dir;

       } else {
	  &message("\r$dst_dir$name\033[K\r");
	  push(@allFiles, "$src_dir$name");
       }
    }
}

$src_dir=".";
$dst_dir=".";
$nb_exclude=0;

@exclude = ();
while (@ARGV) {
    $_ = shift;
    if (/^-x$/) {
	push(@exclude, $_);

    } elsif (/^-d$/) {
	$targetDir = shift;
	$dispatchMode = 1;

    } elsif (/^-help$/) {
	&help;

    } elsif (/^-v$/) {
	$verbose = 1;

    } elsif (/^-/) {
	&help;

    } else {
	$src_dir = $_;
    }
}

$dst_dir=".";
$slink_dir="$src_dir";
&walk_tree("");

sub getComponent {
    local($path) = @_;
    
    if ($path =~ /libgcc.a$/) {
	return "Core";
    }
    if ($path =~ /\.a$/) {
	return "Library";
    }
    if ($path =~ /include/) {
	return "Includes";
    }
    if ($path eq "lib" || $path eq "m6811-elf\\lib") {
	return "Core";
    }
    if ($path =~ /ldscripts/) {
	return "Core";
    }
    if ($path =~ /gcc-lib/) {
	return "Core";
    }
    if ($path =~ /ranlib/) {
	return "Core";
    }
    if ($path =~ /lib/) {
	return "Library";
    }
    if ($path =~ /doc/) {
	return "Documentation";
    }
    if ($path =~ /man/) {
	return "Documentation";
    }
    return "Core";
}

print <<EOF;
[Setup]
    MinVersion=4.0,4.0
    AppName=GNU Development Chain for 68HC11/12
    AppId=GNU 68HC11/12
    CreateUninstallRegKey=1
    UsePreviousAppDir=1
    UsePreviousGroup=1
    AppVersion=2.91
    AppVerName=68HC11/12
    AppCopyright=Copyright 1999, 2000, 2001, 2002, 2003, 2004 Free Software Foundation.
    WizardStyle=modern
    WizardImageFile=gnu-install.bmp
    WizardSmallImageFile=gnu-m68hc1x.bmp
    UninstallStyle=modern
    WindowShowCaption=0
    WindowStartMaximized=0
    WindowVisible=0
    WindowResizable=0
    UninstallLogMode=Overwrite
    DirExistsWarning=0
    UninstallFilesDir={app}
    DisableDirPage=0
    DisableStartupPrompt=0
    CreateAppDir=1
    DisableProgramGroupPage=0
    AlwaysShowComponentsList=1
    ChangesAssociations=1
    Uninstallable=1
    DefaultDirName=c:\\usr
    DefaultGroupName=GNU\\68HC11
    Compression=bzip
    LicenseFile=..\\GPL.txt
    OutputBaseFilename=gnu-hc1x-2.91
    ShowComponentSizes=1
    SourceDir=.
    OutputDir=..

;  Inno Setup Extensions
[Types]
    Name: "full"; Description: "Full installation"
    Name: "compact"; Description: "Compact installation"; Flags: iscustom

[Components]
    Name: "Documentation"; Description: "Hmtl and man page documentation"; Types: full
    Name: "Includes"; Description: "Header files"; Types: full compact
    Name: "Core"; Description: "Compiler and Tools"; ExtraDiskSpaceRequired: 8000000; Types: full compact
    Name: "Library"; Description: "Libraries"; Types: full

EOF

print "[Dirs]\n";
for ($i = 0; $i < $#allDirs; $i++) {
    $dir=$allDirs[$i];
    $dir =~ s,^./,,;
    $dir =~ s,/,\\,g;
    $component = &getComponent($dir);
    print "  Name: {app}\\$dir; Components: $component\n";
}

$baseDir="m6811";
print "\n";
print "[Files]\n";
for ($i = 0; $i < $#allFiles; $i++) {
    $file = $allFiles[$i];
    $dst = Dirname($file);
    $name = Basename($file);
    $file =~ s,^./,,;
    $file =~ s,/,\\,g;
    $dst =~ s,^./,,;
    $dst =~ s,/,\\,g;
    $component = &getComponent($file);
    print "  Source: $baseDir\\$file; DestDir: {app}\\$dst; ";
    print "DestName: $name; ";
    print "Flags: comparetimestamp";

    # Treat the index.html entry as the readme file to show after install
    if ($component == "Documentation" && $name =~ /index\.html$/) {
	print " isreadme";
    }
    print "; Components: $component";
    print "\n";
}

print <<EOF;
[Icons]
   Name: {group}\\General; Filename: {app}\\m6811-elf\\doc\\index.html; WorkingDir: {app}; IconIndex: 0; Flags: useapppaths; Components: Documentation
   Name: {group}\\Assembler; Filename: {app}\\m6811-elf\\doc\\as_doc.html; WorkingDir: {app}; IconIndex: 0; Flags: useapppaths; Components: Documentation
   Name: {group}\\Compiler; Filename: {app}\\m6811-elf\\doc\\gcc_doc.html; WorkingDir: {app}; IconIndex: 0; Flags: useapppaths; Components: Documentation
   Name: {group}\\Linker; Filename: {app}\\m6811-elf\\doc\\ld_doc.html; WorkingDir: {app}; IconIndex: 0; Flags: useapppaths; Components: Documentation
   Name: {group}\\Debugger; Filename: {app}\\m6811-elf\\doc\\gdb_doc.html; WorkingDir: {app}; IconIndex: 0; Flags: useapppaths; Components: Documentation
   Name: {group}\\Utilities; Filename: {app}\\m6811-elf\\doc\\binutils_doc.html; WorkingDir: {app}; IconIndex: 0; Flags: useapppaths; Components: Documentation

[INI]

[Registry]
    Root: HKLM; SubKey: "Software\\Free Software Foundation"; ValueName: GNU; ValueType: string; ValueData: {app}; Flags: deletevalue uninsdeletevalue; Components: Core

[UninstallDelete]
    Type: filesandordirs; Name: "{app}\\m6811-elf\\bin"
    Type: filesandordirs; Name: "{app}\\m6811-elf\\lib"
    Type: filesandordirs; Name: "{app}\\lib\\gcc-lib\\m6811-elf"

[InstallDelete]

[Run]
Filename: {app}\\bin\\winstall.exe; Parameters: "-q"; WorkingDir: {app}; Flags: runminimized skipifdoesntexist

[UninstallRun]

EOF
